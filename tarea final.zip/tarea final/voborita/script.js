const ctx = pintura.getContext('2d');
let objetos = [];
const minRad = 15;
const naveRad = 20; // Tamaño fijo de la nave
let x = 0, y = 0;
let finJuego = false;
let puntaje = 0;

// Guardar balas disparadas
let balas = [];

// Actualizar puntaje en tiempo real
function actualizarPuntaje() {
    document.getElementById('puntaje').innerText = `Puntaje: ${puntaje} `;
}

// Generar enemigos dinámicamente
function generarEnemigo() {
    const tamaño = Math.random() * 20 + 10; // Tamaño entre 10 y 30
    const vida = Math.ceil(tamaño / 10); // Vida depende del tamaño (1, 2 o 3)
    const velocidad = Math.random() * 2 + 1; // Velocidad entre 1 y 3
    const x = Math.random() * pintura.width;
    objetos.push({ x: x, y: 0, width: tamaño, color: getRandomColor(), velocidad, vida });
}

// Generar color aleatorio
function getRandomColor() {
    return `#${Math.floor(Math.random() * 16777215).toString(16)} `;
}

// Colisión entre dos objetos (ajuste para que mueran si son rozados)
function colision(objecto1, objecto2) {
    const distancia = Math.sqrt((objecto2.x - objecto1.x) ** 2 + (objecto2.y - objecto1.y) ** 2);
    return distancia < (objecto1.width / 2 + objecto2.width / 2); // Usar menor que para permitir el roce
}

// Crear balas disparadas
function dispararBala() {
    balas.push({ x: x, y: y, width: 5, velocidad: 5 });
}

// Animación del juego
function animate() {
    ctx.clearRect(0, 0, pintura.width, pintura.height);

    // Animación de enemigos
    objetos.forEach((objeto, index) => {
        ctx.beginPath();
        ctx.arc(objeto.x, objeto.y, objeto.width, 0, Math.PI * 2);
        ctx.fillStyle = objeto.color;
        ctx.fill();
        ctx.stroke();

        // Verificar colisión con balas
        balas.forEach((bala, balaIndex) => {
            if (colision(bala, objeto)) {
                objeto.vida -= 1;
                if (objeto.vida <= 0) {
                    objetos.splice(index, 1); // Eliminar enemigo si muere
                    puntaje += 10;
                    actualizarPuntaje(); // Actualizar puntaje en tiempo real
                }
                balas.splice(balaIndex, 1); // Eliminar bala al colisionar
            }
        });

        // Mover enemigos
        objeto.y += objeto.velocidad;
        if (objeto.y > pintura.height) {
            objeto.y = 0; // Reiniciar posición vertical
            objeto.x = Math.random() * pintura.width; // Cambiar posición horizontal
        }
    });

    // Dibujo de la nave controlada por el mouse
    ctx.beginPath();
    ctx.arc(x, y, naveRad, 0, Math.PI * 2);
    ctx.fillStyle = '#1288AA';
    ctx.fill();
    ctx.stroke();

    // Dibujo de las balas
    balas.forEach(bala => {
        bala.y -= bala.velocidad; // Mover las balas hacia arriba
        ctx.beginPath();
        ctx.arc(bala.x, bala.y, bala.width, 0, Math.PI * 2);
        ctx.fillStyle = '#FF0000';
        ctx.fill();
        ctx.stroke();
    });

    // Dibujo del borde del canvas
    ctx.beginPath();
    ctx.rect(1, 1, pintura.width - 1, pintura.height - 1);
    ctx.stroke();

    // Verificar si la nave colisiona con algún enemigo
    if (objetos.some(objeto => colision({ x: x, y: y, width: naveRad }, objeto))) {
        finJuego = true;
    }

    // Mostrar GAME OVER si el juego ha terminado
    if (finJuego) {
        ctx.font = "30px Arial";
        ctx.fillStyle = 'black';
        ctx.fillText(`GAME OVER! Puntaje: ${puntaje} `, pintura.width / 2 - 150, pintura.height / 2);
    } else {
        requestAnimationFrame(animate); // Continuar la animación
    }
}

// Actualizar posición del mouse
pintura.addEventListener('mousemove', (info) => {
    const rect = pintura.getBoundingClientRect();
    x = info.clientX - rect.left;
    y = info.clientY - rect.top;
});

// Añadir evento de clic para disparar
pintura.addEventListener('click', dispararBala);

// Generar enemigos cada cierto tiempo
setInterval(generarEnemigo, 1000); // Generar un enemigo por segundo

// Iniciar animación
animate();
