// YouTube API Player Initialization
let player = null;

function onYouTubeIframeAPIReady() {
    player = new YT.Player('youtube-player', {
        height: '0',
        width: '0',
        playerVars: { autoplay: 1, controls: 0 },
    });
}

// Search Music
const searchBar = document.getElementById('search-bar');
const searchResults = document.getElementById('search-results');

searchBar.addEventListener('input', async () => {
    const query = searchBar.value.trim();
    if (query.length < 3) return;

    try {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=${encodeURIComponent(query)}&key=AIzaSyD-eOfZgpXb5tecpu0oujDnw7zz0P8Lueo&maxResults=10`
        );
        const data = await response.json();

        searchResults.innerHTML = data.items
            .map(
                (video) => `
                <div class="track">
                    <p><strong>${video.snippet.title}</strong></p>
                    <button onclick="playTrack('${video.id.videoId}', '${video.snippet.title}', '${video.snippet.channelTitle}', '${video.snippet.thumbnails.high.url}')">Reproducir</button>
                </div>`
            )
            .join('');
    } catch (error) {
        console.error('Error al buscar canciones:', error);
    }
});

// Playlists
let playlists = JSON.parse(localStorage.getItem('playlists')) || [];
const mainContent = document.querySelector('main');

// Load Playlists
document.getElementById('menu-playlist').addEventListener('click', () => {
    const playlistsHTML = playlists.map(
        (playlist, index) => `
            <div class="playlist">
                <h3>${playlist.name} (${playlist.tracks.length} canciones)</h3>
                <ul>
                    ${playlist.tracks
                        .map(
                            (track) => `
                            <li>
                                <span>${track.title}</span>
                                <button onclick="playTrack('${track.videoId}', '${track.title}', '', '')">Reproducir</button>
                            </li>`
                        )
                        .join('')}
                </ul>
            </div>`
    );

    mainContent.innerHTML = playlistsHTML.join('') || '<p>No hay listas de reproducción disponibles.</p>';
});

// Add Tracks to Playlist
function addToPlaylistPrompt(title, videoId) {
    const playlistName = prompt('¿A qué lista de reproducción agregar?', 'Mis Favoritos');
    if (!playlistName) return;

    let playlist = playlists.find((p) => p.name === playlistName);
    if (!playlist) {
        playlist = { name: playlistName, tracks: [] };
        playlists.push(playlist);
    }

    playlist.tracks.push({ title, videoId });
    localStorage.setItem('playlists', JSON.stringify(playlists));
}

// Play Track
function playTrack(videoId, title, channel, thumbnail) {
    const audioPlayer = document.getElementById('audio-player');
    const nowPlaying = document.getElementById('now-playing');
    nowPlaying.textContent = `Reproduciendo ahora: ${title}`;
    audioPlayer.src = `https://www.youtube.com/watch?v=${videoId}`;
    audioPlayer.play();
}
